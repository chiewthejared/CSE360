import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

import application.ReviewerList;
import javafx.stage.Stage;
import javafx.application.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

class EditReviewTest {

	@Test
	void test() {
		ReviewerList reviewerlist = new ReviewerList();
		try {
			reviewerlist.show(new Stage(), "Mooey001");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
