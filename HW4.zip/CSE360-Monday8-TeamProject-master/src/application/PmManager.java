package application;
import javafx.application.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
/**
 * JavaFX scene that handles sending a private message to a user
 */
public class PmManager {
	public static void show(Stage superStage, String user) throws FileNotFoundException {
		superStage.setTitle("Private Message");
		
		Button submitPM = new Button("Send a PM");
		Button cancel = new Button("Cancel");
		
		Label prompt = new Label("Enter your private message");
		
		Label p = new Label("Enter the person you want to DM");
		Label f = new Label("Enter your message body");
		
		TextField Person = new TextField();
		TextField Body = new TextField();
		
		Body.setTranslateY(-50.0);
		
		p.setTranslateY(-70);
		f.setTranslateY(-20);
		
		StackPane layout = new StackPane();
		
		// Submits a private message when clicked
		submitPM.setOnAction(e -> {
			try {
				BufferedWriter writer = new BufferedWriter(new FileWriter("pm.csv", true));
				writer.write(user + "," + Body.getText() + "," + Person.getText() + "\n");
				writer.close();
				superStage.close();
			}	
			catch (IOException e1){
				e1.printStackTrace();
			}
		});
		
		// Close window
		cancel.setOnAction(e -> {
			superStage.close();
		});
		
		layout.getChildren().addAll(submitPM, cancel, Person, Body, prompt, p, f);
		
		StackPane.setAlignment(submitPM, Pos.BOTTOM_LEFT);
		StackPane.setAlignment(cancel, Pos.BOTTOM_RIGHT);
		
		StackPane.setAlignment(prompt, Pos.TOP_CENTER);
		
		Scene scene = new Scene(layout, 600, 300);
		
		superStage.setScene(scene);
		superStage.show();
		
	}
}