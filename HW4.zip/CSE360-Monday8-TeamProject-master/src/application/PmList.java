package application;
import javafx.application.*;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;
/**
 * JavaFX scene that handles showing the user their private messages
 */
public class PmList {
	public static void show(Stage superStage, String user) throws IOException {
		superStage.setTitle("Private Messages List");
		
		File file = new File("pm.csv");
		
		Scanner scn = new Scanner(file);
		
		ListView<String> pms = new ListView<>();
		Button close = new Button ("Close");
		VBox pmViewer = new VBox();
		Label r = new Label();
		
		close.setOnAction(e -> {
			superStage.close();
		});
		
		// Show private messages to ListView
		while (scn.hasNextLine()) {
			String[] msgs = scn.nextLine().split(",");
			if (msgs[1].equals(user)) {
				pms.getItems().add(msgs[2]);
			}
		}
		
		// Show who wrote the pm when list view element is clicked
		pms.setOnMouseClicked(e -> {
			try {
				Scanner scn1 = new Scanner(file);
				pmViewer.getChildren().clear();
				while (scn1.hasNextLine()) {
					String[] msgs = scn1.nextLine().split(",");
					if (msgs[2].equals(pms.getSelectionModel().getSelectedItem())) {
						r.setText(msgs[0] + " says " + msgs[2]);
						pmViewer.getChildren().add(r);
					}
			  }
			}
				catch (FileNotFoundException e1) {
				e1.printStackTrace();
			}
			
		});
		
		
		
		HBox buttonBox = new HBox(4, close);
		
		BorderPane bdrLayout = new BorderPane();
		bdrLayout.setCenter(pmViewer);
		bdrLayout.setLeft(pms);
		bdrLayout.setBottom(buttonBox);
		
		Scene scene = new Scene(bdrLayout, 600, 400);
		
		superStage.setScene(scene);
		superStage.show();
	}
}
