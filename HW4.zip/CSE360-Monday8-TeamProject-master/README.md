# Team Project Phase 3
Reviewer: Mooey001

Admin : Mooey

Student : Zalmindo1

These are the people used in our test. They are hard-coded in and do not pull from the database

For the csv files to work properly, make sure they are properly aligned as in

test1,test2

input1,input2

Code Screencast: https://drive.google.com/file/d/1w_bfh7TSYHRsrG1Zqln0h4UEE12pofuk/view?usp=sharing

Architecture and Design screencast : https://drive.google.com/file/d/1fGfkNVSDy83ddU4fRBMH9fRTv1Hrz0Fw/view?usp=sharing

Standup Meeting 3-29-25 : https://drive.google.com/file/d/1VrMFpbYWrNH31J-I-TIlISFHo-bk_8jj/view?usp=sharing

Standup Meeting 4-2-25 : https://drive.google.com/file/d/1UvNZwp3QJJJeVE3wUzu28ThnjiE34rHW/view?usp=sharing

