import org.junit.jupiter.api.*;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class AutomatedTesting {
    private static QuestionsCollection questionsCollection;
    private static AnswersCollection answersCollection;

    @BeforeEach
    void setup() {
        questionsCollection = new QuestionsCollection();
        answersCollection = new AnswersCollection();
    }

    @Test
    // Test 1 - Posts a question to check if user can post a question
    void testPostQuestion() {
        questionsCollection.addQuestion("What is the capital of France?");
        List<Question> questions = questionsCollection.getAllQuestions();
        assertEquals(1, questions.size());
        assertEquals("What is the capital of France?", questions.get(0).getQuestionText());
    }

    @Test
    // Test 2 - After posting a question, checks if user can edit the question posted
    void testEditQuestion() {
        questionsCollection.addQuestion("What is the capital of France?");
        Question question = questionsCollection.getAllQuestions().get(0);
        String newQuestionText = "What is the capital city of France?";
        question = new Question(newQuestionText); // Simulate editing
        questionsCollection.getAllQuestions().set(0, question);

        assertEquals("What is the capital city of France?", questionsCollection.getAllQuestions().get(0).getQuestionText());
    }

    @Test
    // Test 3 - Answers a question to check if user can post an answer
    void testAnswerQuestion() {
        questionsCollection.addQuestion("What is the capital of France?");
        Question question = questionsCollection.getAllQuestions().get(0);
        answersCollection.addAnswer(question.getId(), "The capital is Paris.");

        List<Answer> answers = question.getAnswers();
        assertEquals(1, answers.size());
        assertEquals("The capital is Paris.", answers.get(0).getAnswerText());
    }

    @Test
    // Test 4 - After posting an answer, checks if user can edit the answer posted
    void testEditAnswer() {
        questionsCollection.addQuestion("What is the capital of France?");
        Question question = questionsCollection.getAllQuestions().get(0);
        answersCollection.addAnswer(question.getId(), "The capital is Paris.");

        Answer answer = question.getAnswers().get(0);
        String newAnswerText = "Paris is the capital of France.";
        answer = new Answer(newAnswerText); // Simulate editing
        question.getAnswers().set(0, answer);

        assertEquals("Paris is the capital of France.", question.getAnswers().get(0).getAnswerText());
    }

    @Test
    // Test 5 - Adds 2 questions and sees if all the questions posted can be viewed
    void testViewAllQuestions() {
        questionsCollection.addQuestion("What is the capital of France?");
        questionsCollection.addQuestion("What is the tallest mountain in the world?");
        List<Question> questions = questionsCollection.getAllQuestions();

        assertEquals(2, questions.size());
        assertEquals("What is the capital of France?", questions.get(0).getQuestionText());
        assertEquals("What is the tallest mountain in the world?", questions.get(1).getQuestionText());
    }
}
